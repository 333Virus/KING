package com.asociety.modules.misc;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class TimeChanger extends Module {
    public TimeChanger() { super("TimeChanger", "TimeChanger misc module.", Category.MISC); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
