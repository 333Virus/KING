package com.asociety.modules.optimizer;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class MemoryCleaner extends Module {
    public MemoryCleaner() { super("MemoryCleaner", "MemoryCleaner optimizer module.", Category.OPTIMIZER); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
