package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class AutoClicker extends Module {
    public AutoClicker() { super("AutoClicker", "AutoClicker module.", Category.COMBAT); }

    @Override
    protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override
    protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        // AutoClicker logic placeholder - implement per feature spec
    }
}
