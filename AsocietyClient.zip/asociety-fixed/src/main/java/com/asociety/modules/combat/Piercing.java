package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class Piercing extends Module {
    public Piercing() { super("Piercing", "Piercing module.", Category.COMBAT); }

    @Override
    protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override
    protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        // Piercing logic placeholder - implement per feature spec
    }
}
