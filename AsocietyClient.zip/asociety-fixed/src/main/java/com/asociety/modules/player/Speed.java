package com.asociety.modules.player;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class Speed extends Module {
    public Speed() { super("Speed", "Speed player module.", Category.PLAYER); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
