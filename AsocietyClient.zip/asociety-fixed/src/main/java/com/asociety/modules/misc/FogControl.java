package com.asociety.modules.misc;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class FogControl extends Module {
    public FogControl() { super("FogControl", "FogControl misc module.", Category.MISC); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
