package com.asociety.modules.visual;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class PearlTrajectory extends Module {
    public PearlTrajectory() { super("PearlTrajectory", "PearlTrajectory visual module.", Category.VISUAL); }

    @Override protected void registerListeners() {
        bus().subscribe(Events.Render3DEvent.class, e -> onRender3D(e));
    }
    @Override protected void unregisterListeners() {
        bus().unsubscribe(Events.Render3DEvent.class, e -> onRender3D(e));
    }
    private void onRender3D(Events.Render3DEvent event) {
        if (mc.player == null || mc.level == null) return;
    }
}
