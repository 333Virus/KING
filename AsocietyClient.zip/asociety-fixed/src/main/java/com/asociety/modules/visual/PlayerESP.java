package com.asociety.modules.visual;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
import com.asociety.module.Setting.BooleanSetting;
import com.asociety.module.Setting.SliderSetting;
import com.asociety.module.Setting.ModeSetting;
import com.asociety.utils.RenderUtils;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

public class PlayerESP extends Module {
    private final BooleanSetting box      = addSetting(new BooleanSetting("Box",      true));
    private final BooleanSetting filled   = addSetting(new BooleanSetting("Filled",   true));
    private final BooleanSetting tracers  = addSetting(new BooleanSetting("Tracers",  false));
    private final SliderSetting lineWidth = addSetting(new SliderSetting("Line Width", 1.0, 0.5, 3.0));
    private final SliderSetting fillAlpha = addSetting(new SliderSetting("Fill Alpha", 40.0, 0.0, 255.0));

    public PlayerESP() { super("PlayerESP", "Renders boxes around players.", Category.VISUAL); }

    @Override protected void registerListeners() {
        bus().subscribe(Events.Render3DEvent.class, this::onRender3D);
    }
    @Override protected void unregisterListeners() {
        bus().unsubscribe(Events.Render3DEvent.class, this::onRender3D);
    }

    private void onRender3D(Events.Render3DEvent event) {
        if (mc.player == null || mc.level == null) return;
        int espColor = color.getARGB();
        int fillColor = (espColor & 0x00FFFFFF) | ((int) fillAlpha.getValue().intValue() << 24);

        for (Player p : mc.level.players()) {
            if (p == mc.player) continue;
            AABB bb = p.getBoundingBox();

            if (filled.getValue()) {
                RenderUtils.drawFilledBox(bb, fillColor);
            }
            if (box.getValue()) {
                RenderUtils.drawBoundingBox(bb, espColor, (float) lineWidth.getValue());
            }
        }
    }
}
