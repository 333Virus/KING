package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class NoSlow extends Module {
    public NoSlow() { super("NoSlow", "NoSlow module.", Category.COMBAT); }

    @Override
    protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override
    protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        // NoSlow logic placeholder - implement per feature spec
    }
}
