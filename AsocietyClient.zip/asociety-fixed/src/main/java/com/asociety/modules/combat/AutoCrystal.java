package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
import com.asociety.module.Setting.BooleanSetting;
import com.asociety.module.Setting.SliderSetting;
import com.asociety.module.Setting.ModeSetting;
import com.asociety.utils.MathUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AutoCrystal extends Module {
    private final SliderSetting placeRange  = addSetting(new SliderSetting("Place Range",  5.0, 1.0, 8.0));
    private final SliderSetting breakRange  = addSetting(new SliderSetting("Break Range",  5.0, 1.0, 8.0));
    private final SliderSetting minDamage   = addSetting(new SliderSetting("Min Damage",   6.0, 1.0, 36.0));
    private final SliderSetting maxSelf     = addSetting(new SliderSetting("Max Self Dmg", 8.0, 0.0, 36.0));
    private final SliderSetting delay       = addSetting(new SliderSetting("Delay (ms)",  50.0, 0.0, 500.0));
    private final BooleanSetting antiSuicide = addSetting(new BooleanSetting("Anti Suicide", true));
    private final BooleanSetting predictive  = addSetting(new BooleanSetting("Predictive",   true));

    private long lastAction = 0;

    public AutoCrystal() { super("AutoCrystal", "Automatically places and breaks end crystals.", Category.COMBAT); }

    @Override protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (System.currentTimeMillis() - lastAction < (long) delay.getValue()) return;

        // Find best target
        Player target = findBestTarget();
        if (target == null) return;

        // 1. Break existing crystals in range
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof net.minecraft.world.entity.boss.enderdragon.EndCrystal)) continue;
            double dist = mc.player.distanceTo(e);
            if (dist > breakRange.getValue()) continue;
            mc.player.connection.send(ServerboundInteractPacket.createAttackPacket(e, mc.player.isShiftKeyDown()));
            lastAction = System.currentTimeMillis();
            return;
        }

        // 2. Find best placement pos
        BlockPos best = findBestPlacement(target);
        if (best == null) return;

        Vec3 hitVec = Vec3.atCenterOf(best).add(0, 0.5, 0);
        mc.player.connection.send(new ServerboundUseItemOnPacket(
                InteractionHand.MAIN_HAND,
                new BlockHitResult(hitVec, net.minecraft.core.Direction.UP, best, false),
                0));
        lastAction = System.currentTimeMillis();
    }

    private Player findBestTarget() {
        return mc.level.players().stream()
                .filter(p -> p != mc.player && !p.isDeadOrDying())
                .filter(p -> mc.player.distanceTo(p) <= placeRange.getValue() + 4)
                .min(Comparator.comparingDouble(p -> mc.player.distanceTo(p)))
                .orElse(null);
    }

    private BlockPos findBestPlacement(Player target) {
        Vec3 playerPos = mc.player.position();
        double range   = placeRange.getValue();
        BlockPos best  = null;
        double bestDmg = minDamage.getValue();

        for (int x = (int)(playerPos.x - range); x <= (int)(playerPos.x + range); x++) {
            for (int y = (int)(playerPos.y - 1); y <= (int)(playerPos.y + 2); y++) {
                for (int z = (int)(playerPos.z - range); z <= (int)(playerPos.z + range); z++) {
                    BlockPos pos = new BlockPos(x, y, z);
                    if (!isValidPlacement(pos)) continue;

                    Vec3 crystalPos = Vec3.atCenterOf(pos).add(0, 1, 0);
                    double targetDmg = MathUtils.crystalDamage(crystalPos, target.position(), (float) target.getHealth());
                    double selfDmg   = MathUtils.crystalDamage(crystalPos, mc.player.position(), (float) mc.player.getHealth());

                    if (antiSuicide.getValue() && selfDmg >= mc.player.getHealth()) continue;
                    if (selfDmg > maxSelf.getValue()) continue;

                    if (predictive.getValue()) {
                        Vec3 predicted = target.position().add(target.getDeltaMovement());
                        double pdmg = MathUtils.crystalDamage(crystalPos, predicted, (float) target.getHealth());
                        targetDmg = Math.max(targetDmg, pdmg);
                    }

                    if (targetDmg > bestDmg) { bestDmg = targetDmg; best = pos; }
                }
            }
        }
        return best;
    }

    private boolean isValidPlacement(BlockPos pos) {
        if (mc.level == null) return false;
        var state = mc.level.getBlockState(pos);
        if (state.getBlock() != Blocks.OBSIDIAN && state.getBlock() != Blocks.BEDROCK) return false;
        BlockPos above = pos.above();
        BlockPos above2 = pos.above(2);
        return mc.level.getBlockState(above).isAir() && mc.level.getBlockState(above2).isAir()
               && mc.player.distanceTo(Vec3.atCenterOf(above)) <= placeRange.getValue();
    }
}
