package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
import com.asociety.module.Setting.BooleanSetting;
import com.asociety.module.Setting.SliderSetting;
import com.asociety.module.Setting.ModeSetting;
import com.asociety.utils.MathUtils;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class KillAura extends Module {
    private final SliderSetting range   = addSetting(new SliderSetting("Range", 4.0, 1.0, 8.0));
    private final SliderSetting cps     = addSetting(new SliderSetting("CPS",   10.0, 1.0, 20.0));
    private final BooleanSetting players = addSetting(new BooleanSetting("Players", true));
    private final BooleanSetting mobs    = addSetting(new BooleanSetting("Mobs",    true));
    private final BooleanSetting rotate  = addSetting(new BooleanSetting("Rotate",  true));
    private final ModeSetting sort = addSetting(new ModeSetting("Sort", "Distance", "Distance", "Health", "Angle"));

    private long lastHit = 0;

    public KillAura() { super("KillAura", "Attacks nearby entities automatically.", Category.COMBAT); }

    @Override protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        long interval = (long)(1000.0 / cps.getValue());
        if (System.currentTimeMillis() - lastHit < interval) return;

        List<LivingEntity> targets = getTargets();
        if (targets.isEmpty()) return;

        LivingEntity target = targets.get(0);
        if (rotate.getValue()) {
            float[] rots = MathUtils.getRotations(mc.player.getEyePosition(), target.getEyePosition());
            mc.player.setYRot(rots[0]);
            mc.player.setXRot(rots[1]);
        }
        mc.player.connection.send(ServerboundInteractPacket.createAttackPacket(target, mc.player.isShiftKeyDown()));
        mc.player.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
        lastHit = System.currentTimeMillis();
    }

    private List<LivingEntity> getTargets() {
        LocalPlayer p = mc.player;
        double r = range.getValue();
        return StreamSupport.stream(mc.level.entitiesForRendering().spliterator(), false)
                .filter(e -> e instanceof LivingEntity && e != p && !((LivingEntity)e).isDeadOrDying())
                .filter(e -> p.distanceTo(e) <= r)
                .filter(e -> (players.getValue() && e instanceof Player)
                          || (mobs.getValue() && e instanceof Monster)
                          || (e instanceof LivingEntity && !(e instanceof Player) && !(e instanceof Monster)))
                .map(e -> (LivingEntity) e)
                .sorted(switch (sort.getValue()) {
                    case "Health"   -> Comparator.comparingDouble(LivingEntity::getHealth);
                    case "Angle"    -> Comparator.comparingDouble(e -> angleToEntity(p, e));
                    default         -> Comparator.comparingDouble(p::distanceTo);
                })
                .collect(Collectors.toList());
    }

    private double angleToEntity(LocalPlayer p, Entity e) {
        float[] rots = MathUtils.getRotations(p.getEyePosition(), e.getEyePosition());
        double dy = Math.abs(rots[0] - p.getYRot()) % 360;
        double dp = Math.abs(rots[1] - p.getXRot());
        return dy + dp;
    }
}
