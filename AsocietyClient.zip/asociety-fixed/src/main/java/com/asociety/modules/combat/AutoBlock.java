package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class AutoBlock extends Module {
    public AutoBlock() { super("AutoBlock", "AutoBlock module.", Category.COMBAT); }

    @Override
    protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override
    protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        // AutoBlock logic placeholder - implement per feature spec
    }
}
