package com.asociety.modules.combat;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class Reach extends Module {
    public Reach() { super("Reach", "Reach module.", Category.COMBAT); }

    @Override
    protected void registerListeners() {
        bus().subscribe(Events.TickEvent.class, e -> onTick());
    }
    @Override
    protected void unregisterListeners() {
        bus().unsubscribe(Events.TickEvent.class, e -> onTick());
    }

    private void onTick() {
        if (mc.player == null || mc.level == null) return;
        // Reach logic placeholder - implement per feature spec
    }
}
