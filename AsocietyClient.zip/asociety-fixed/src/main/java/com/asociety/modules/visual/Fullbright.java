package com.asociety.modules.visual;

import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;

public class Fullbright extends Module {
    private float prevGamma = 1.0f;

    public Fullbright() { super("Fullbright", "Increases gamma for night vision.", Category.VISUAL); }

    @Override
    protected void onEnable() {
        if (mc.options != null) {
            prevGamma = (float)(double) mc.options.gamma().get();
            mc.options.gamma().set(16.0);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) {
            mc.options.gamma().set((double) prevGamma);
        }
    }
}
