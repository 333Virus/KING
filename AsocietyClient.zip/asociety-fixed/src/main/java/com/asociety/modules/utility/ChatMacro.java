package com.asociety.modules.utility;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class ChatMacro extends Module {
    public ChatMacro() { super("ChatMacro", "ChatMacro utility module.", Category.UTILITY); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
