package com.asociety.modules.utility;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class AutoMine extends Module {
    public AutoMine() { super("AutoMine", "AutoMine utility module.", Category.UTILITY); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
