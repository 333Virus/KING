package com.asociety.modules.exploration;
import com.asociety.event.Events;
import com.asociety.module.Category;
import com.asociety.module.Module;
public class SlimeChunk extends Module {
    public SlimeChunk() { super("SlimeChunk", "SlimeChunk exploration module.", Category.EXPLORATION); }
    @Override protected void registerListeners() { bus().subscribe(Events.TickEvent.class, e -> onTick()); }
    @Override protected void unregisterListeners() { bus().unsubscribe(Events.TickEvent.class, e -> onTick()); }
    private void onTick() { if (mc.player == null) return; }
}
