package com.asociety.module;

public enum Category {
    COMBAT("Combat"),
    VISUAL("Visual"),
    UTILITY("Utility"),
    EXPLORATION("Exploration"),
    PLAYER("Player"),
    HUD("HUD"),
    OPTIMIZER("Optimizer"),
    MISC("Misc");

    public final String name;
    Category(String name) { this.name = name; }
}
