package com.asociety.module;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    // Default: Light Yellow #FFFACD
    public static final Color DEFAULT_COLOR = new Color(0xFF, 0xFA, 0xCD);
    public static final Color GOLD = new Color(0xFF, 0xD7, 0x00);

    public ColorSetting(String name) {
        super(name, DEFAULT_COLOR);
    }

    public ColorSetting(String name, Color def) {
        super(name, def);
    }

    public int getRed()   { return value.getRed(); }
    public int getGreen() { return value.getGreen(); }
    public int getBlue()  { return value.getBlue(); }
    public int getAlpha() { return value.getAlpha(); }

    public int getARGB() {
        return (value.getAlpha() << 24) | (value.getRed() << 16) | (value.getGreen() << 8) | value.getBlue();
    }

    public int getRGB() { return value.getRGB(); }

    public ColorSetting withAlpha(int alpha) {
        Color c = value;
        value = new Color(c.getRed(), c.getGreen(), c.getBlue(), alpha);
        return this;
    }
}
