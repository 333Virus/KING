package com.asociety.module;

import com.asociety.modules.combat.*;
import com.asociety.modules.visual.*;
import com.asociety.modules.utility.*;
import com.asociety.modules.exploration.*;
import com.asociety.modules.player.*;
import com.asociety.modules.optimizer.*;
import com.asociety.modules.misc.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // Combat
        register(new AutoCrystal(), new AutoTotem(), new KillAura(), new Reach(),
                 new AimAssist(), new Velocity(), new AutoClicker(), new Criticals(),
                 new AntiKnockback(), new AutoBlock(), new AutoShield(), new Backtrack(),
                 new Blink(), new FakeLag(), new FastSwitch(), new HitboxExpand(),
                 new KnockbackDelay(), new NoSlow(), new ShieldBreaker(), new SilentAim(),
                 new MaceSwap(), new AutoMace(), new AnchorMacro(), new Piercing());

        // Visual
        register(new PlayerESP(), new BlockESP(), new StorageESP(), new ItemESP(),
                 new MobESP(), new Fullbright(), new CrystalESP(), new TNTESP(),
                 new EntityESP(), new VoidESP(), new PortalESP(), new OutlineESP(),
                 new GlowESP(), new Breadcrumbs(), new MotionTrails(), new NameTags(),
                 new HealthBars(), new DamagePop(), new ArmorHUD(), new Crosshair(),
                 new PearlTrajectory(), new JumpCircles(), new ChunkBorders(),
                 new Waypoints(), new Atmosphere());

        // Utility
        register(new BaseFinder(), new StashFinder(), new NewChunks(), new FastPlace(),
                 new FastBreak(), new AutoRespawn(), new AutoEat(), new AutoTool(),
                 new AutoWalk(), new AutoMine(), new AutoFish(), new NoFall(),
                 new SafeWalk(), new Scaffold(), new Timer(), new ElytraFly(),
                 new NoWeb(), new FastLadder(), new FastSwim(), new SpeedMine(),
                 new ChatMacro(), new AutoDisconnect());

        // Exploration
        register(new Freecam(), new MiniMap(), new Coords(), new BiomeDisplay(),
                 new SlimeChunk(), new CaveFinder(), new StructureFinder(),
                 new PathFinder(), new HeightMap(), new LightOverlay());

        // Player
        register(new Sprint(), new Speed(), new Flight(), new Jesus(),
                 new Step(), new LongJump(), new Sneak(), new Strafe(),
                 new EdgeJump(), new Glide(), new FastClimb(), new YawLock(),
                 new AntiPush(), new NoJumpDelay());

        // Optimizer
        register(new FPSBoost(), new EntityCulling(), new ParticleLimiter(),
                 new ChunkOptimizer(), new MemoryCleaner(), new DynamicResolution(),
                 new NetworkThrottle());

        // Misc
        register(new DiscordPresence(), new NameProtect(), new SkinProtect(),
                 new TimeChanger(), new FogControl(), new GammaControl(),
                 new FOVMod(), new ConfigManager(), new ThemeEditor(),
                 new AutoUpdate(), new RageMacro(), new TriggerBot(),
                 new FakeStats(), new NoHitDelay());
    }

    private void register(Module... mods) {
        for (Module m : mods) modules.add(m);
    }

    public List<Module> getAll()                      { return modules; }
    public Module getByName(String name)              { return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null); }
    public List<Module> getByCategory(Category cat)  { return modules.stream().filter(m -> m.getCategory() == cat).collect(Collectors.toList()); }
    public boolean isEnabled(String name)             { Module m = getByName(name); return m != null && m.isEnabled(); }
}
