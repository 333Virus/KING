package com.asociety.module;

import com.asociety.event.EventBus;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final Minecraft mc = Minecraft.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int key = -1;

    public final ColorSetting color = new ColorSetting("Color");
    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        settings.add(color);
    }

    public void toggle() {
        if (enabled) disable(); else enable();
    }

    public void enable() {
        enabled = true;
        onEnable();
        registerListeners();
    }

    public void disable() {
        enabled = false;
        onDisable();
        unregisterListeners();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    protected void registerListeners() {}
    protected void unregisterListeners() {}

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public Category getCategory()  { return category; }
    public boolean isEnabled()     { return enabled; }
    public int getKey()            { return key; }
    public void setKey(int key)    { this.key = key; }
    public List<Setting<?>> getSettings() { return settings; }

    protected EventBus bus() { return EventBus.getInstance(); }

    protected <T extends Setting<?>> T addSetting(T s) {
        settings.add(s);
        return s;
    }
}
