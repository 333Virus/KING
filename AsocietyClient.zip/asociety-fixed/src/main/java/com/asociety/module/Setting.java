package com.asociety.module;

public abstract class Setting<T> {
    protected final String name;
    protected T value;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public T getValue() { return value; }
    public void setValue(T value) { this.value = value; }

    public static class BooleanSetting extends Setting<Boolean> {
        public BooleanSetting(String name, boolean def) { super(name, def); }
        public void toggle() { value = !value; }
    }

    public static class SliderSetting extends Setting<Double> {
        private final double min, max;
        public SliderSetting(String name, double def, double min, double max) {
            super(name, def);
            this.min = min;
            this.max = max;
        }
        public double getMin() { return min; }
        public double getMax() { return max; }
    }

    public static class ModeSetting extends Setting<String> {
        private final String[] modes;
        public ModeSetting(String name, String def, String... modes) {
            super(name, def);
            this.modes = modes;
        }
        public String[] getModes() { return modes; }
        public void cycle() {
            for (int i = 0; i < modes.length; i++) {
                if (modes[i].equals(value)) {
                    value = modes[(i + 1) % modes.length];
                    return;
                }
            }
        }
    }
}
