package com.asociety.gui;

import com.asociety.main.Asociety;
import com.asociety.module.Category;
import com.asociety.module.Module;
import com.asociety.module.Setting;
import com.asociety.utils.ColorUtils;
import com.asociety.utils.RenderUtils;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class ClickGuiScreen extends Screen {
    // Palette
    private static final int BG           = 0xE5000000;
    private static final int SIDEBAR_BG   = 0xF5121212;
    private static final int CARD_BG      = 0xCC1A1A1A;
    private static final int CARD_HOVER   = 0xCC242424;
    private static final int GOLD         = 0xFFFFD700;
    private static final int LIGHT_YELLOW = 0xFFFFFFACD;
    private static final int WHITE        = 0xFFFFFFFF;
    private static final int GREY         = 0xFF555555;

    // Layout
    private static final int SIDEBAR_W = 100;
    private static final int HEADER_H  = 28;
    private static final int CARD_W    = 120;
    private static final int CARD_H    = 36;
    private static final int CARD_PAD  = 6;
    private static final int COLS      = 3;

    private Category activeCategory = Category.COMBAT;
    private int scrollY = 0;
    private int hoveredCardIdx = -1;

    public ClickGuiScreen() {
        super(Component.literal("Asociety Client"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int sw = this.width, sh = this.height;
        int panelX = sw / 2 - 300, panelY = sh / 2 - 200;
        int panelW = 600, panelH = 400;

        // overall background
        g.fill(0, 0, sw, sh, 0x88000000);

        // panel bg
        RenderUtils.drawRect(g, panelX, panelY, panelW, panelH, BG);

        // header bar
        RenderUtils.drawGradientRect(g, panelX, panelY, panelW, HEADER_H, 0xFF1A1A1A, 0xFF0A0A0A);
        g.drawCenteredString(this.font, "§6§lASOCIETY §r§7Client", panelX + panelW / 2, panelY + 8, WHITE);

        // sidebar
        renderSidebar(g, panelX, panelY + HEADER_H, SIDEBAR_W, panelH - HEADER_H, mouseX, mouseY);

        // module grid
        renderModuleGrid(g, panelX + SIDEBAR_W, panelY + HEADER_H, panelW - SIDEBAR_W, panelH - HEADER_H, mouseX, mouseY);

        // thin gold border
        RenderUtils.drawOutlineRect(g, panelX, panelY, panelW, panelH, GOLD & 0x88FFFFFF, 1);

        super.render(g, mouseX, mouseY, delta);
    }

    private void renderSidebar(GuiGraphics g, int x, int y, int w, int h, int mx, int my) {
        RenderUtils.drawRect(g, x, y, w, h, SIDEBAR_BG);

        Category[] cats = Category.values();
        int tabH = 32;
        for (int i = 0; i < cats.length; i++) {
            Category cat = cats[i];
            int ty = y + i * tabH;
            boolean active = cat == activeCategory;
            boolean hovered = mx >= x && mx < x + w && my >= ty && my < ty + tabH;

            int bg = active ? 0xFF1E1E1E : (hovered ? 0xFF181818 : 0xFF121212);
            RenderUtils.drawRect(g, x, ty, w, tabH, bg);

            if (active) {
                // gold indicator bar on left
                RenderUtils.drawRect(g, x, ty, 3, tabH, GOLD);
            }

            int textColor = active ? GOLD : (hovered ? LIGHT_YELLOW : 0xFFAAAAAA);
            g.drawString(this.font, cat.name, x + 12, ty + tabH / 2 - 4, textColor);
        }
    }

    private void renderModuleGrid(GuiGraphics g, int x, int y, int w, int h, int mx, int my) {
        RenderUtils.drawRect(g, x, y, w, h, 0xFF0D0D0D);

        List<Module> modules = (Asociety.getInstance() != null && Asociety.getInstance().getModuleManager() != null) ? Asociety.getInstance().getModuleManager().getByCategory(activeCategory) : java.util.Collections.emptyList();
        int startX = x + CARD_PAD;
        int startY = y + CARD_PAD + scrollY;
        int col = 0, row = 0;

        for (int i = 0; i < modules.size(); i++) {
            Module mod = modules.get(i);
            int cx = startX + col * (CARD_W + CARD_PAD);
            int cy = startY + row * (CARD_H + CARD_PAD);

            if (cy + CARD_H < y || cy > y + h) { // scroll culling
                col++;
                if (col >= COLS) { col = 0; row++; }
                continue;
            }

            boolean hovered = mx >= cx && mx < cx + CARD_W && my >= cy && my < cy + CARD_H;
            boolean enabled = mod.isEnabled();

            // card bg
            RenderUtils.drawRect(g, cx, cy, CARD_W, CARD_H, hovered ? CARD_HOVER : CARD_BG);

            // left color strip when enabled
            if (enabled) {
                RenderUtils.drawRect(g, cx, cy, 2, CARD_H, GOLD);
            }

            // name
            g.drawString(this.font, mod.getName(), cx + 7, cy + 6, WHITE);

            // toggle indicator
            int toggleX = cx + CARD_W - 24;
            int toggleY = cy + CARD_H / 2 - 5;
            int toggleBg = enabled ? GOLD : GREY;
            RenderUtils.drawRoundedRect(g, toggleX, toggleY, 20, 10, 5, toggleBg);
            int knobX = enabled ? toggleX + 12 : toggleX + 2;
            RenderUtils.drawRect(g, knobX, toggleY + 2, 6, 6, WHITE);

            col++;
            if (col >= COLS) { col = 0; row++; }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sw = this.width, sh = this.height;
        int panelX = sw / 2 - 300, panelY = sh / 2 - 200;
        int panelW = 600, panelH = 400;

        // sidebar click
        if (mx >= panelX && mx < panelX + SIDEBAR_W && my >= panelY + HEADER_H) {
            Category[] cats = Category.values();
            int tabH = 32;
            int idx = (int)((my - panelY - HEADER_H) / tabH);
            if (idx >= 0 && idx < cats.length) {
                activeCategory = cats[idx];
                scrollY = 0;
                return true;
            }
        }

        // module grid click
        if (mx >= panelX + SIDEBAR_W && my >= panelY + HEADER_H) {
            int gx = panelX + SIDEBAR_W + CARD_PAD;
            int gy = panelY + HEADER_H + CARD_PAD + scrollY;
            List<Module> modules = (Asociety.getInstance() != null && Asociety.getInstance().getModuleManager() != null) ? Asociety.getInstance().getModuleManager().getByCategory(activeCategory) : java.util.Collections.emptyList();
            int col = 0, row = 0;
            for (Module mod : modules) {
                int cx = gx + col * (CARD_W + CARD_PAD);
                int cy = gy + row * (CARD_H + CARD_PAD);
                if (mx >= cx && mx < cx + CARD_W && my >= cy && my < cy + CARD_H) {
                    if (button == 0) mod.toggle();
                    return true;
                }
                col++;
                if (col >= COLS) { col = 0; row++; }
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double dx, double dy) {
        scrollY += (int)(dy * 12);
        if (scrollY > 0) scrollY = 0;
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
