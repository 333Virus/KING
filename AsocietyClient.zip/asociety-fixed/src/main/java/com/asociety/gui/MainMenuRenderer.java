package com.asociety.gui;

import com.asociety.main.Asociety;
import com.asociety.utils.RenderUtils;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;

public class MainMenuRenderer {
    // Black & Gold palette
    private static final int BG_TOP     = 0xFF050505;
    private static final int BG_BOTTOM  = 0xFF0F0F0F;
    private static final int GOLD       = 0xFFFFD700;
    private static final int LIGHT_YELLOW = 0xFFFFFFACD;
    private static final int BTN_BG     = 0xCC121212;
    private static final int BTN_HOVER  = 0xCC1E1E1E;

    public static void renderBackground(GuiGraphics g, int w, int h) {
        // dark gradient bg
        RenderUtils.drawGradientRect(g, 0, 0, w, h, BG_TOP, BG_BOTTOM);

        // subtle horizontal fog bands
        for (int i = 0; i < 5; i++) {
            int fogY = h / 2 + i * 30 - 60;
            int alpha = (int)(20 - i * 3);
            if (alpha > 0) {
                RenderUtils.drawGradientRect(g, 0, fogY, w, 20, 0x00000000, (alpha << 24) | 0xFFFFACD);
            }
        }
    }

    public static void renderLogo(GuiGraphics g, int w, int h, net.minecraft.client.gui.Font font) {
        // main title
        String title = "ASOCIETY";
        int titleColor = LIGHT_YELLOW;

        // shadow
        g.drawCenteredString(font, "§l" + title, w / 2 + 1, h / 2 - 90 + 1, 0x44000000);
        g.drawCenteredString(font, "§l" + title, w / 2, h / 2 - 90, titleColor);

        // subtitle
        g.drawCenteredString(font, "§7Client §8v" + Asociety.VERSION, w / 2, h / 2 - 76, 0xFFAAAAAA);

        // gold divider line
        int lineW = 160, lineX = w / 2 - lineW / 2, lineY = h / 2 - 68;
        RenderUtils.drawGradientRect(g, lineX, lineY, lineW / 2, 1, 0x00FFD700, GOLD);
        RenderUtils.drawGradientRect(g, w / 2, lineY, lineW / 2, 1, GOLD, 0x00FFD700);
    }

    public static void renderButton(GuiGraphics g, int x, int y, int w, int h,
                                     String label, boolean hovered, net.minecraft.client.gui.Font font) {
        int bg = hovered ? BTN_HOVER : BTN_BG;
        int borderColor = hovered ? GOLD : (GOLD & 0x44FFFFFF);
        RenderUtils.drawRoundedRect(g, x, y, w, h, 3, bg);
        RenderUtils.drawOutlineRect(g, x, y, w, h, borderColor, 1);
        int textColor = hovered ? LIGHT_YELLOW : 0xFFCCCCCC;
        g.drawCenteredString(font, label, x + w / 2, y + h / 2 - 4, textColor);
    }
}
