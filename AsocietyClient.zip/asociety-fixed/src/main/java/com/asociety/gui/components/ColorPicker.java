package com.asociety.gui.components;

import com.asociety.module.ColorSetting;
import com.asociety.utils.RenderUtils;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.Color;

public class ColorPicker {
    private final ColorSetting setting;
    private float hue = 0f, saturation = 1f, brightness = 1f, alpha = 1f;
    private boolean draggingHue = false, draggingSV = false, draggingAlpha = false;

    public ColorPicker(ColorSetting setting) {
        this.setting = setting;
        float[] hsb = Color.RGBtoHSB(setting.getRed(), setting.getGreen(), setting.getBlue(), null);
        hue = hsb[0]; saturation = hsb[1]; brightness = hsb[2];
        alpha = setting.getAlpha() / 255f;
    }

    public void render(GuiGraphics g, int x, int y) {
        int sw = 150, sh = 150, hw = 10, aw = 10;

        // SV square
        for (int px = 0; px < sw; px++) {
            float s = (float) px / sw;
            int topColor    = Color.HSBtoRGB(hue, s, 1f);
            int bottomColor = Color.HSBtoRGB(hue, s, 0f);
            g.fillGradient(x + px, y, x + px + 1, y + sh, topColor, bottomColor);
        }

        // Hue bar
        for (int i = 0; i < sh; i++) {
            int hueColor = Color.HSBtoRGB((float)i / sh, 1f, 1f);
            RenderUtils.drawRect(g, x + sw + 4, y + i, hw, 1, hueColor | 0xFF000000);
        }

        // Alpha bar
        for (int i = 0; i < sh; i++) {
            float a = 1f - (float) i / sh;
            int c = Color.HSBtoRGB(hue, saturation, brightness);
            int ac = ((int)(a * 255) << 24) | (c & 0x00FFFFFF);
            RenderUtils.drawRect(g, x + sw + hw + 8, y + i, aw, 1, ac);
        }

        // SV cursor
        int svX = (int)(x + saturation * sw);
        int svY = (int)(y + (1f - brightness) * sh);
        RenderUtils.drawRect(g, svX - 3, svY - 1, 6, 2, 0xFFFFFFFF);
        RenderUtils.drawRect(g, svX - 1, svY - 3, 2, 6, 0xFFFFFFFF);

        updateColor();
    }

    public boolean mouseClicked(int mx, int my, int x, int y, int button) {
        return false; // extend with actual drag handling
    }

    private void updateColor() {
        int rgb = Color.HSBtoRGB(hue, saturation, brightness);
        setting.setValue(new Color(
            (rgb >> 16) & 0xFF,
            (rgb >> 8) & 0xFF,
            rgb & 0xFF,
            (int)(alpha * 255)
        ));
    }
}
