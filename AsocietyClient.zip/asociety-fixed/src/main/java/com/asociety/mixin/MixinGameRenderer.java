package com.asociety.mixin;

import com.asociety.event.EventBus;
import com.asociety.event.Events;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void onRenderLevel(float tickDelta, long limitTime, com.mojang.blaze3d.vertex.PoseStack pose, CallbackInfo ci) {
        EventBus.getInstance().post(new Events.Render3DEvent(tickDelta));
    }
}
