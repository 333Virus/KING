package com.asociety.mixin;
import org.spongepowered.asm.mixin.Mixin;
// MixinAbstractClientPlayer - extend with event injections as needed
@Mixin(net.minecraft.client.Minecraft.class)
public class MixinAbstractClientPlayer {}
