package com.asociety.mixin;

import com.asociety.gui.MainMenuRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class MixinTitleScreen {

    @Inject(method = "render", at = @At("HEAD"), cancellable = false)
    private void onRenderHead(GuiGraphics g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        TitleScreen self = (TitleScreen)(Object)this;
        MainMenuRenderer.renderBackground(g, self.width, self.height);
        MainMenuRenderer.renderLogo(g, self.width, self.height, self.getMinecraft().font);
    }
}
