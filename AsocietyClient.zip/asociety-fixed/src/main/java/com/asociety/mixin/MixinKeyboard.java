package com.asociety.mixin;

import com.asociety.event.EventBus;
import com.asociety.event.Events;
import com.asociety.main.Asociety;
import com.asociety.module.Module;
import net.minecraft.client.KeyboardHandler;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Only handles module keybinds now.
 * ClickGUI is opened via Fabric KeyBinding (RIGHT SHIFT) in Asociety.java
 * — same reliable method used by FastClient HUD on 1.21.11.
 */
@Mixin(KeyboardHandler.class)
public class MixinKeyboard {

    @Inject(method = "keyPress", at = @At("HEAD"))
    private void onKeyPress(long window, int key, int scancode, int action, int mods, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.getWindow() == null || window != mc.getWindow().getWindow()) return;

        EventBus.getInstance().post(new Events.KeyInputEvent(key, action));

        // Module keybinds only when no screen is open
        if (mc.screen == null && Asociety.getInstance() != null) {
            for (Module m : Asociety.getInstance().getModuleManager().getAll()) {
                if (m.getKey() == key) {
                    m.toggle();
                    break;
                }
            }
        }
    }
}
