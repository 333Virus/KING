package com.asociety.mixin;

import com.asociety.main.Asociety;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.SplashOverlay;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Custom loading screen (replaces red Mojang splash).
 * Black background + ASOCIETY / CLIENT + gold progress bar.
 * Pattern inspired by how polished clients brand their splash.
 */
@Mixin(SplashOverlay.class)
public class MixinSplashOverlay {

    private static final int BG          = 0xFF000000;
    private static final int TITLE       = 0xFFFFFACD; // light yellow
    private static final int SUBTITLE    = 0xFFFFD700; // gold
    private static final int BAR_BORDER  = 0xFF333333;
    private static final int BAR_BG      = 0xFF1A1A1A;
    private static final int BAR_FILL    = 0xFFFFD700;

    @Shadow @Final private Minecraft minecraft;
    @Shadow private float currentProgress;

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void asociety$splash(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        try {
            int w = this.minecraft.getWindow().getGuiScaledWidth();
            int h = this.minecraft.getWindow().getGuiScaledHeight();

            // solid black
            g.fill(0, 0, w, h, BG);

            // title
            String title = "§lASOCIETY";
            int tx = (w - this.minecraft.font.width(title)) / 2;
            int ty = h / 2 - 52;
            g.drawString(this.minecraft.font, title, tx + 1, ty + 1, 0x44000000, false);
            g.drawString(this.minecraft.font, title, tx, ty, TITLE, false);

            // subtitle
            String sub = "CLIENT";
            int sx = (w - this.minecraft.font.width(sub)) / 2;
            g.drawString(this.minecraft.font, sub, sx, ty + 16, SUBTITLE, false);

            // version
            String ver = "v" + Asociety.VERSION;
            int vx = (w - this.minecraft.font.width(ver)) / 2;
            g.drawString(this.minecraft.font, ver, vx, ty + 30, 0xFF666666, false);

            // progress bar
            int barW = 220, barH = 3;
            int bx = (w - barW) / 2;
            int by = h / 2 + 40;
            float p = Math.max(0f, Math.min(1f, this.currentProgress));

            g.fill(bx - 1, by - 1, bx + barW + 1, by + barH + 1, BAR_BORDER);
            g.fill(bx, by, bx + barW, by + barH, BAR_BG);
            int filled = (int) (barW * p);
            if (filled > 0) {
                g.fill(bx, by, bx + filled, by + barH, BAR_FILL);
            }

            // percent text
            String pct = (int) (p * 100) + "%";
            int px = (w - this.minecraft.font.width(pct)) / 2;
            g.drawString(this.minecraft.font, pct, px, by + 10, 0xFF888888, false);

            ci.cancel();
        } catch (Throwable ignored) {
            // fall through to original Mojang splash if anything fails
        }
    }
}
