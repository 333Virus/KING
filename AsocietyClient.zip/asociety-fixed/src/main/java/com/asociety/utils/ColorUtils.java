package com.asociety.utils;

import java.awt.Color;

public class ColorUtils {
    public static final int GOLD       = 0xFFFFD700;
    public static final int LIGHT_YELLOW = 0xFFFFFFACD;
    public static final int BLACK      = 0xFF000000;
    public static final int DARK_GREY  = 0xFF121212;
    public static final int WHITE      = 0xFFFFFFFF;

    public static int toARGB(Color c) {
        return (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }

    public static int withAlpha(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    public static Color rainbow(long offset) {
        float hue = ((System.currentTimeMillis() + offset) % 2000) / 2000f;
        return Color.getHSBColor(hue, 1f, 1f);
    }

    public static int lerp(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        int a = (int)(a1 + (a2 - a1) * t);
        int r = (int)(r1 + (r2 - r1) * t);
        int g = (int)(g1 + (g2 - g1) * t);
        int b = (int)(b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int darker(int argb, float factor) {
        int a = (argb >> 24) & 0xFF;
        int r = (int)(((argb >> 16) & 0xFF) * factor);
        int g = (int)(((argb >> 8) & 0xFF) * factor);
        int b = (int)((argb & 0xFF) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
