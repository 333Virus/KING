package com.asociety.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.Packet;

public class PacketUtils {
    private static final Minecraft mc = Minecraft.getInstance();

    public static void sendPacket(Packet<?> packet) {
        if (mc.player != null && mc.player.connection != null) {
            mc.player.connection.send(packet);
        }
    }

    public static void sendPacketNoEvent(Packet<?> packet) {
        // bypasses the outbound packet event
        ClientPacketListener conn = mc.player != null ? mc.player.connection : null;
        if (conn != null) conn.send(packet);
    }
}
