package com.asociety.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class RenderUtils {
    private static final Minecraft mc = Minecraft.getInstance();

    // ── 2D ──────────────────────────────────────────────────────────────────

    public static void drawRect(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    public static void drawOutlineRect(GuiGraphics g, int x, int y, int w, int h, int color, int thickness) {
        g.fill(x, y, x + w, y + thickness, color);
        g.fill(x, y + h - thickness, x + w, y + h, color);
        g.fill(x, y, x + thickness, y + h, color);
        g.fill(x + w - thickness, y, x + w, y + h, color);
    }

    public static void drawRoundedRect(GuiGraphics g, int x, int y, int w, int h, int radius, int color) {
        g.fill(x + radius, y, x + w - radius, y + h, color);
        g.fill(x, y + radius, x + radius, y + h - radius, color);
        g.fill(x + w - radius, y + radius, x + w, y + h - radius, color);
        for (int i = 0; i < radius; i++) {
            int len = (int) Math.sqrt((double) (radius * radius - (radius - i) * (radius - i)));
            g.fill(x + radius - len, y + i, x + radius, y + i + 1, color);
            g.fill(x + w - radius, y + i, x + w - radius + len, y + i + 1, color);
            g.fill(x + radius - len, y + h - i - 1, x + radius, y + h - i, color);
            g.fill(x + w - radius, y + h - i - 1, x + w - radius + len, y + h - i, color);
        }
    }

    public static void drawGradientRect(GuiGraphics g, int x, int y, int w, int h, int colorTop, int colorBottom) {
        g.fillGradient(x, y, x + w, y + h, colorTop, colorBottom);
    }

    // ── 3D ESP ───────────────────────────────────────────────────────────────

    public static void drawBoundingBox(AABB box, int color, float lineWidth) {
        if (mc.level == null || mc.gameRenderer == null) return;

        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        double x1 = box.minX - cam.x, y1 = box.minY - cam.y, z1 = box.minZ - cam.z;
        double x2 = box.maxX - cam.x, y2 = box.maxY - cam.y, z2 = box.maxZ - cam.z;

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.lineWidth(lineWidth);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f mat = RenderSystem.getModelViewMatrix();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        // bottom
        line(buf, mat, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buf, mat, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // top
        line(buf, mat, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buf, mat, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buf, mat, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // verticals
        line(buf, mat, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y2, z2, r, g, b, a);

        BufferUploader.drawWithShader(buf.build());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void line(BufferBuilder b, Matrix4f m, double x1, double y1, double z1,
                             double x2, double y2, double z2, float r, float g, float bl, float a) {
        b.addVertex(m, (float)x1, (float)y1, (float)z1).setColor(r, g, bl, a);
        b.addVertex(m, (float)x2, (float)y2, (float)z2).setColor(r, g, bl, a);
    }

    public static void drawFilledBox(AABB box, int color) {
        // filled translucent box for ESP
        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();
        double x1 = box.minX - cam.x, y1 = box.minY - cam.y, z1 = box.minZ - cam.z;
        double x2 = box.maxX - cam.x, y2 = box.maxY - cam.y, z2 = box.maxZ - cam.z;

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f;

        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        Matrix4f mat = RenderSystem.getModelViewMatrix();

        // 6 faces
        quad(buf, mat, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2, r, g, b, a); // bottom
        quad(buf, mat, x1, y2, z1, x2, y2, z1, x2, y2, z2, x1, y2, z2, r, g, b, a); // top
        quad(buf, mat, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1, r, g, b, a); // north
        quad(buf, mat, x1, y1, z2, x1, y2, z2, x2, y2, z2, x2, y1, z2, r, g, b, a); // south
        quad(buf, mat, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2, r, g, b, a); // west
        quad(buf, mat, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2, r, g, b, a); // east

        BufferUploader.drawWithShader(buf.build());
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void quad(BufferBuilder b, Matrix4f m,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             double x3, double y3, double z3, double x4, double y4, double z4,
                             float r, float g, float bl, float a) {
        b.addVertex(m, (float)x1, (float)y1, (float)z1).setColor(r, g, bl, a);
        b.addVertex(m, (float)x2, (float)y2, (float)z2).setColor(r, g, bl, a);
        b.addVertex(m, (float)x3, (float)y3, (float)z3).setColor(r, g, bl, a);
        b.addVertex(m, (float)x4, (float)y4, (float)z4).setColor(r, g, bl, a);
    }
}
