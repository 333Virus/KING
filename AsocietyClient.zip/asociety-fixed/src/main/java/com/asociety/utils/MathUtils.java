package com.asociety.utils;

import net.minecraft.world.phys.Vec3;

public class MathUtils {
    public static float[] getRotations(Vec3 from, Vec3 to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
        return new float[]{ wrapDegrees(yaw), wrapDegrees(pitch) };
    }

    public static float wrapDegrees(float angle) {
        angle %= 360f;
        if (angle >= 180f)  angle -= 360f;
        if (angle < -180f)  angle += 360f;
        return angle;
    }

    public static double distanceTo(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
        return Math.sqrt(dx*dx + dy*dy + dz*dz);
    }

    public static Vec3 interpolate(Vec3 a, Vec3 b, double t) {
        return new Vec3(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t);
    }

    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    public static double crystalDamage(Vec3 explosionPos, Vec3 targetPos, float health) {
        double dist = distanceTo(explosionPos, targetPos);
        if (dist > 12.0) return 0;
        double exposure = 1.0 - (dist / 12.0);
        double impact   = (exposure * exposure + exposure) / 2.0 * 7.0 * 12.0 + 1.0;
        return Math.max(0, impact - health);
    }
}
