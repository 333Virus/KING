package com.asociety.event;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;

public class Events {

    public static class TickEvent {
        public static final TickEvent INSTANCE = new TickEvent();
    }

    public static class RenderEvent {
        public final GuiGraphics graphics;
        public final float tickDelta;
        public RenderEvent(GuiGraphics graphics, float tickDelta) {
            this.graphics = graphics;
            this.tickDelta = tickDelta;
        }
    }

    public static class Render3DEvent {
        public final float tickDelta;
        public Render3DEvent(float tickDelta) { this.tickDelta = tickDelta; }
    }

    public static class PacketEvent {
        public Object packet;
        public boolean cancelled;
        public PacketEvent(Object packet) { this.packet = packet; }
    }

    public static class AttackEvent {
        public final Entity target;
        public boolean cancelled;
        public AttackEvent(Entity target) { this.target = target; }
    }

    public static class MoveEvent {
        public double x, y, z;
        public MoveEvent(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
    }

    public static class KeyInputEvent {
        public final int key;
        public final int action;
        public KeyInputEvent(int key, int action) { this.key = key; this.action = action; }
    }
}
