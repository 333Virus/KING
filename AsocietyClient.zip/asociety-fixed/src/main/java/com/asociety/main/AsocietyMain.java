package com.asociety.main;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common (main) entrypoint. Runs on both client and dedicated server.
 * Client-only logic stays in Asociety (ClientModInitializer).
 */
public class AsocietyMain implements ModInitializer {
    public static final String MOD_ID = "asociety";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[Asociety] Common init — mod registered with Fabric Loader.");
    }
}
