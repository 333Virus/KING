package com.asociety.main;

import com.asociety.gui.ClickGuiScreen;
import com.asociety.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Asociety implements ClientModInitializer {
    public static final String NAME    = "Asociety Client";
    public static final String VERSION = "1.0.4";
    public static final Logger LOGGER  = LoggerFactory.getLogger("asociety");

    private static Asociety instance;
    private ModuleManager moduleManager;
    private KeyMapping clickGuiKey;
    private boolean clickGuiKeyWasDown = false;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[Asociety] Initializing {} v{}", NAME, VERSION);

        moduleManager = new ModuleManager();
        moduleManager.init();

        // RIGHT SHIFT (GLFW 344) — same method FastClient uses for 1.21.11
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.asociety.clickgui",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, // 344
            "key.categories.asociety"
        ));

        // Poll every client tick (edge-triggered)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (clickGuiKey == null) return;

            boolean isDown = clickGuiKey.isDown();
            if (isDown && !clickGuiKeyWasDown) {
                // Key just pressed
                if (client.screen instanceof ClickGuiScreen) {
                    client.setScreen(null);
                } else if (client.screen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            clickGuiKeyWasDown = isDown;
        });

        LOGGER.info("[Asociety] Loaded {} modules. RIGHT SHIFT opens ClickGUI.", moduleManager.getAll().size());
    }

    public static Asociety getInstance()    { return instance; }
    public ModuleManager getModuleManager() { return moduleManager; }
}
