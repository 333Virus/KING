# Asociety Client v1.0.4

Minecraft Fabric client (1.21 – 1.21.11) with ClickGUI, modules, and custom loading screen.

## Why it did not work before (root causes)

1. **Invalid jar in mods folder**  
   The file you put in Zalith was source/ZIP-sized (~128 KB), not a compiled Fabric mod.  
   Fabric ignores invalid jars → mod never appears in the Mods list → no mixins → red Mojang screen + no menu.

2. **Wrong keybind method for 1.21.11**  
   Old code used a raw KeyboardHandler mixin. Working 1.21.11 clients (e.g. FastClient HUD) use **Fabric KeyBinding API** + ClientTickEvents. That is now implemented.

3. **This environment cannot produce a binary jar**  
   Fabric Loom fails here with `UnrecoverableZipException` when downloading Minecraft.  
   A real PC with Java 21 is required to run `./gradlew build`.

## What works in this source (after you build it)

| Feature | How |
|---------|-----|
| Appears in Fabric Mods menu | Valid `fabric.mod.json` + compiled classes |
| Custom loading screen | `MixinSplashOverlay` — black + ASOCIETY / CLIENT + gold bar |
| ClickGUI | RIGHT SHIFT (key 344) via `KeyBindingHelper` |
| Modules list in ClickGUI | `ModuleManager` registers all module classes |
| Module keybinds | `MixinKeyboard` when no screen is open |

## Architecture (aligned with FastClient patterns)

- `AsocietyMain` — `ModInitializer` (common)
- `Asociety` — `ClientModInitializer` (client): ModuleManager + KeyBinding + tick poll
- `ClickGuiScreen` — feature menu (not the Fabric Mods list)
- `MixinSplashOverlay` — branded loading screen
- Modules under `com.asociety.modules.*`

**Note:** The in-game **Mods** button shows Fabric-loaded mods. Asociety’s **feature menu** is the ClickGUI opened with RIGHT SHIFT. Those are two different UIs.

## Build (required)

```bash
# Java 21 required
cd asociety-fixed
./gradlew build          # Linux/macOS
gradlew.bat build        # Windows
```

Output:
```
build/libs/asociety-client-1.0.4.jar
```

Install:
1. Delete any old `asocietyclient.jar` from the mods folder
2. Copy `asociety-client-1.0.4.jar` into the mods folder
3. Ensure Fabric Loader + Fabric API are installed for your MC version
4. Launch — Asociety Client must appear in the Mods list
5. RIGHT SHIFT opens ClickGUI

## Optional: target exact 1.21.11

On your PC, in `build.gradle` change:
```gradle
minecraft 'com.mojang:minecraft:1.21.11'
```
and matching Fabric API version for 1.21.11, then rebuild.

## Honest limitations

- Most modules are stubs (toggle works; full combat/visual logic is placeholder).
- Splash mixin cancels the vanilla render; progress field is still used for the bar.
- Cannot ship a pre-built jar from this environment.
